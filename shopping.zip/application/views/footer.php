  </div><!-- /.container -->

<div style="clear: both"></div>
	  <div class="row footer">
		<div class="container">
			<p>Online Shopping</p>
		</div>
	</div>
	


    
  </body>
</html>
