
<div class="container">
<div class="row details">
						<div class="col-md-12 text-center">
							<h3>Thank you!</h3>
							
							<div class="details-description" style="margin-bottom:250px ">
								Your order has been placed!
							</div>
							
							
						</div>
</div>