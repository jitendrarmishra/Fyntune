		<div class="panel panel-default panel-list">
				<div class="panel-heading panel-heading-dark">
					 <h3 class="panel-title">
						Categories
					</h3>
				</div>
				<!-- List group -->
				<ul class="list-group">
					<?php foreach(get_categories_h() as $category) : ?>
						<li class="list-group-item"><a href="<?php echo base_url(); ?>products/category/<?php echo base64_encode($category->id); ?>"><?php echo $category->name; ?></a></li>
					<?php endforeach; ?>		
				</ul>
			</div>
			