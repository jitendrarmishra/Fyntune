<?php
class Product_model extends CI_Model{
	/*
	* Get All Products
	*/
	public function get_products(){
		$this->db->select('*');
		$this->db->from('products');
		$query = $this->db->get();
		return $query->result();
	}
	/*
	* Get Single Product
	*/
	
	public function get_product_details($id){
		$this->db->select('*');
		$this->db->from('products');
		$this->db->where('id', $id);
		$query = $this->db->get();
		return $query->row();
	}

	public function get_product_compare($id){
		$this->db->select('*');
		$this->db->from('products');
		$this->db->where_in('id', $id);
		$query = $this->db->get();
		return $query->result();
	}
	/*
	* Get Categories
	*/


	
	
	public function get_categories(){
		$this->db->select('*');
		$this->db->from('categories');
		$query = $this->db->get();
		return $query->result();
	}

	public function category_name($id){
		$this->db->select('*');
		$this->db->from('categories');
		$this->db->where('id', $id);
		$query = $this->db->get();
		return $query->row();
	}



public function get_category_product($id){
		$this->db->select('*');
		$this->db->from('products');
		$this->db->where('category_id', $id);
		$query = $this->db->get();
		return $query->result();
	}

	/*
	* Get Most Popular Products
	*/
	
	public function get_popular(){
		$this->db->select('P.*, COUNT(O.product_id) as total');
		$this->db->from('orders AS O');
		$this->db->join('products AS P', 'O.product_id = P.id', 'INNER');
		$this->db->group_by('O.product_id');
		$this->db->order_by('total', 'desc');
		$query = $this->db->get();
		return $query->result();
	}
    
    
	/*
	 *	Add Order To Database
	 */
	 public function add_order($order_data){
		$insert = $this->db->insert('orders', $order_data);
        return $insert;
	}

	public function add_user($order_data){
		$insert = $this->db->insert('users', $order_data);
        return $insert;
	}

	public function add_wishlist($product_id,$user_id,$order_data){

		$this->db->where('product_id',$product_id);
		$this->db->where('user_id',$user_id);
		$q = $this->db->get('wishlist');

		if ( $q->num_rows() == 0) 
		{
			$insert = $this->db->insert('wishlist', $order_data);
        	return $insert;
		} 


		
	}
}