			<?php if($this->session->flashdata('registered')) : ?>
		<div class="alert alert-success">
		    <?php echo $this->session->flashdata('registered'); ?>
		</div>
		<?php endif; ?>
		<?php if($this->session->flashdata('pass_login')) : ?>
		<div class="alert alert-success">
		    <?php echo $this->session->flashdata('pass_login'); ?>
		</div>
		<?php endif; ?>

		<?php if($this->session->flashdata('fail_login')) : ?>
		<div class="alert alert-danger">
		    <?php echo $this->session->flashdata('fail_login'); ?>
		</div>
		<?php endif; ?>

		<div class="container">

		 <div class="row">
		  
				 	<div class="col-md-8">
					<div class="panel panel-default">
					<div class="panel-heading panel-heading-green">
						<h3 class="panel-title">All Products List</h3>
					</div>
					<div class="panel-body">

		<?php
		if(!empty($products))
		{
		 foreach($products as $product) : ?>
		
		<div class="col-md-6 game" style="border: solid 1px; margin-bottom: 10px; padding: 10px;height: 550px">
						<div class="game-price">&#x20B9;<?php echo $product->price; ?></div>
						<a href="<?php echo base_url(); ?>products/details/<?php echo $product->id; ?>">
							<img style="height:400px" src="<?php echo $product->image; ?>" />
						</a>
						<div class="game-title">
							<?php echo $product->title; ?>
						</div>
						<div>
							<form method="post" action="<?php echo base_url(); ?>cart/add">
								Qty: <input class="qty" type="text" name="qty" value="1" /><br>
								<input type="hidden" name="item_number" value="<?php echo $product->id; ?>" />
								<input type="hidden" name="price" value="<?php echo $product->price; ?>" />
								<input type="hidden" name="title" value="<?php echo $product->title; ?>" />

								<!-- <div class="col-md-12 row"> -->
								<button style="margin-right: 5px" class="btn btn-primary col-md-3" name="action" value="cart" type="submit">Add to Cart</button>
								 
								<!-- </div> -->
							</form>				

						</div>
					</div>
					
		<?php endforeach; }else
		{?>
			<div class="col-md-6 game">Product not found!</div>
		<?php }?>


		
					
			 	</div>
			 	</div>
		</div>

	<div class="col-md-4">
					<?php $this->load->view('right_sidebar'); ?>
				
				</div>




	</div><!-- /.row -->
		
