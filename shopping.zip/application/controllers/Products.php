<?php
class Products extends CI_Controller{
	public function index(){
		//Get All Products
		$jsonData = $this->get_curl('https://fakestoreapi.com/products');
		$data['products'] = json_decode($jsonData);
		$this->load->view('header', $data);
		$this->load->view('index');
		$this->load->view('footer');
	}


	public function details($id){
		//Get Product Details
		$product_id =	$this->uri->segment(3);
		$jsonData = $this->get_curl('https://fakestoreapi.com/products/'.$product_id);
		$data['product'] = json_decode($jsonData);
		//Load View
		$this->load->view('header');
		$this->load->view('details', $data);
		$this->load->view('footer');
	}

	public function get_curl($url){
			//  Initiate curl
			$ch = curl_init();
			// Disable SSL verification
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			// Will return the response, if false it print the response
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			// Set the url
			curl_setopt($ch, CURLOPT_URL,$url);
			// Execute
			$result=curl_exec($ch);
			return $result;
			// Closing
			// curl_close($ch);

			// // Will dump a beauty json :3
			// var_dump(json_decode($result, true));
	}
	
}