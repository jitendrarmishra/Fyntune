<?php

class Cart extends CI_Controller{
	public $paypal_data = '';
	public $tax;
	public $shipping;
	public $total = 0;
	public $grand_total;
	
	/*
	 *	Cart Index
	 */
	 public function index(){
		//Load View
		$this->load->view('header');
		$this->load->view('cart');
		$this->load->view('footer');

	 }
	 

	 public function success(){
		//Load View
		$this->load->view('header');
		$this->load->view('success');
		$this->load->view('footer');

	 }

	 /*
	  * Add To Cart
	  */
	  public function add(){
		$action = $this->input->post('action');
		
		if($action == 'cart')
		{
			//Item Data
			$data = array(
					'id' => $this->input->post('item_number'),
					'qty' => $this->input->post('qty'),
					'price' => $this->input->post('price'),
					'name' => $this->input->post('title')
			);
			//Insert Into Cart
			$this->cart->insert($data);
		}
		redirect(base_url());
	  }
	  
	  /*
	 * Update Cart
	 */
	public function update($in_cart = null){
		$data = $_POST;
		$this->cart->update($data);
		//Show Cart Page
		redirect(base_url());
		// redirect('cart','refresh');

	}


	public function clear_cart($in_cart = null){
		$this->cart->destroy();
          redirect(base_url());
	}


	
	
	/*
	 *	Process Form
	 */
	 public function process(){

	 	$transaction_id = (rand(10,100));


	 			$order_data = array(
				'first_name'   		=> $this->input->post('first_name'),
				'last_name'      	=> $this->input->post('last_name'),
				'email'      		=> $this->input->post('email'),
				'address'   		=> $this->input->post('address'),
				'mobile'   		=> $this->input->post('mobile'),
				'city'      		=> $this->input->post('city'),
				'state'      		=> $this->input->post('state'),
				'zipcode'      		=> $this->input->post('zipcode')
				);
				
				//Add User Data
				echo $user_id = $this->Product_model->add_user($order_data);

// die;
	 	foreach($this->input->post('item_name') as $key => $value){
				//Get tax & shipping from config
				$this->tax = $this->config->item('tax');
				$this->shipping = $this->config->item('shipping');
				$item_id = $this->input->post('item_code')[$key]; 
				$product = $this->Product_model->get_product_details($item_id);
				$subtotal=($product->price * $this->input->post('item_qty')[$key]);
				
				//Create Order Array
				$order_data = array(
				'product_id' 		=> $item_id,
				'user_id'  			=> $user_id,
				'transaction_id'  	=> $transaction_id,
				'qty'            	=> $this->input->post('item_qty')[$key],
				'price'      		=> $subtotal,
				);
				
				//Add Order Data
				$this->Product_model->add_order($order_data);
			}

			$this->cart->destroy();
			$this->session->set_flashdata('pass_login', 'Your order has been placed!');
          redirect(base_url('cart/success'));

	 }
}